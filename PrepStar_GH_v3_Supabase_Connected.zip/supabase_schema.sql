-- PrepStar GH starter schema (run in Supabase SQL Editor)
-- Creates private student profiles and learning activity. Do not store passwords here.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null default 'Student',
  username text unique,
  school_level text not null default 'JHS 3',
  points integer not null default 0 check (points >= 0),
  created_at timestamptz not null default now()
);
create table if not exists public.learning_activity (
  id uuid primary key default gen_random_uuid(),
  student_id uuid not null references auth.users(id) on delete cascade,
  activity_type text not null,
  activity_name text not null,
  score integer,
  created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.learning_activity enable row level security;
drop policy if exists "Students view own profile" on public.profiles;
create policy "Students view own profile" on public.profiles for select to authenticated using (auth.uid() = id);
drop policy if exists "Students create own profile" on public.profiles;
create policy "Students create own profile" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "Students update own profile" on public.profiles;
create policy "Students update own profile" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);
drop policy if exists "Students view own activity" on public.learning_activity;
create policy "Students view own activity" on public.learning_activity for select to authenticated using (auth.uid() = student_id);
drop policy if exists "Students record own activity" on public.learning_activity;
create policy "Students record own activity" on public.learning_activity for insert to authenticated with check (auth.uid() = student_id);
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles (id, full_name, username, school_level)
  values (new.id,
    coalesce(new.raw_user_meta_data ->> 'full_name', 'Student'),
    nullif(new.raw_user_meta_data ->> 'username', ''),
    coalesce(new.raw_user_meta_data ->> 'school_level', 'JHS 3'))
  on conflict (id) do nothing;
  return new;
end;
$$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute function public.handle_new_user();
